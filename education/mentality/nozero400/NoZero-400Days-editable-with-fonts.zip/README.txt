NoZero 400 Days — 편집용 PowerPoint

43장 · 발표 계획 20분
한국어: Pretendard (400/600/700/800/900)
영문 디스플레이: Barlow Condensed (600/700)

편집 전 fonts 폴더의 글꼴을 설치하면 원래 서체를 유지할 수 있습니다.
글꼴은 SIL Open Font License 1.1에 따라 동봉하며 각 라이선스는 licenses 폴더에 있습니다.
영상 보기 링크는 인터넷 연결이 필요합니다. 웹 발표 화면은 수동 질문·답변 전환과 영상 재생을 지원합니다.
