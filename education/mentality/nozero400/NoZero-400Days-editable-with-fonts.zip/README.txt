NoZero 400 Days · 편집용 발표

Hub 웹 발표와 PDF는 폰트를 추가 설치하지 않아도 동일한 화면으로 볼 수 있습니다.

PPTX 편집본은 fonts 폴더의 TTF 5개를 설치한 뒤 PowerPoint 또는 Keynote를 다시 열면 지정한 서체로 표시됩니다.

서체 라이선스는 licenses 폴더에 포함되어 있습니다.
